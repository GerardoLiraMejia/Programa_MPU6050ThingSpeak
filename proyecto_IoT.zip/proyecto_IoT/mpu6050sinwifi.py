from machine import I2C, Pin 
from imu import MPU6050
from time import sleep

i2c = I2C(0, scl=Pin(5), sda=Pin(4))

imu = MPU6050(i2c)

while True:
  ax = imu.accel.x
  ay = imu.accel.y
  az = imu.accel.z
  
  
  print("ax:", ax, "ay: ", ay, "az:", az)
  
  sleep(1)