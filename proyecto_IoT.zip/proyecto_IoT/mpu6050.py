from machine  import I2C, Pin 
import  network, urequests
from imu import MPU6050
from time import sleep
from time import time

ssid = 'FamLM.2.4'
password = '117201HgC_8d'
url = "https://api.thingspeak.com/update?api_key=SN9E2J4GCF6VBUK7&field1=0"
red = network.WLAN(network.STA_IF)


red.active(True)
red.connect(ssid, password)


while red.isconnected() == False:
  pass
print('Conexión correcta')
print(red.ifconfig())

ultima_peticion = 0
intervalo_peticiones = 30

def reconectar():
    print('Fallo de conexión. Reconectando...')
    time.sleep(10)
    machine.reset()

i2c = I2C(0, scl=Pin(5), sda=Pin(4))


imu = MPU6050(i2c)

while True:
    try:
        # Obtener datos del sensor IMU
        ax = imu.accel.x
        ay = imu.accel.y
        az = imu.accel.z

        # Enviar datos a ThingSpeak
        if (time() - ultima_peticion) > intervalo_peticiones:
            response = urequests.get(url + "&field1=" + str(ax) + "&field2=" + str(ay) + "&field3=" + str(az))
            print("Respuesta: " + str(response.status_code))
            response.close()
            ultima_peticion = time()

    except OSError as e:
        # Manejar errores de conexión
        print("Error de conexión:", e)
        # Aquí puedes añadir la lógica de reconexión, si es necesario
 
  